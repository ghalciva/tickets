const mongoose = require('mongoose');

const asignedSchema = new mongoose.Schema({
    username: {
        type: mongoose.Schema.ObjectId, 
        ref: "User"
    },
    subject: {
        type: mongoose.Schema.ObjectId, 
        ref: "Ticket"
    },
    priority: { 
        type: mongoose.Schema.ObjectId, 
        ref: "Ticket"
     },
    state: { type: String, enum: ['Terminado', 'En proceso'], default: 'En proceso' },
    asigned: { type: String, default: 'Pepe Ortiz' },
    created: { 
        type: mongoose.Schema.ObjectId, 
        ref: "Ticket"
     }
});

// create the model for user and expose it to our app
module.exports = mongoose.model('Asigned', asignedSchema); 