const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    subject: String,
    description: String,
    priority: { type: String, enum: ['Baja', 'Media', 'Alta'], default: 'Baja' },
    created: { type: Date, default: Date.now }
});

// create the model for user and expose it to our app
module.exports = mongoose.model('Ticket', ticketSchema);